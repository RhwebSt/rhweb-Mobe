
<?php $__env->startSection('conteine'); ?>
<div class="container">
            <div class="row">
                <div class="btn mt-3 form-control" role="button" aria-label="Basic example">
                    <a class="btn ms-2 text-white" href="#" role="button" style="background-color: #194bf0;">Incluir</a>
                    <button type="button" class="btn ms-2  col-md-1 text-white" data-bs-toggle="modal" data-bs-target="#staticBackdrop" style="background-color: #194bf0;">
                        Excluir
                      </button>
                      <a class="btn  btn-md ms-2 col-md-1 text-white" href="#" role="button" style="background-color: #194bf0;;" >Editar</a>
                      <a class="btn ms-2 col-md-1 text-white" href="#" style="background-color: #194bf0;" role="button">Sair</a>
                </div>
            </div>
        </div>

        <h1 class="container text-center mt-3 fs-4 mb-5">Lançamento com Tabela de Preços</h1>

        <div class="responsive mt-5">
            <div class="table-bordered border-white" >
                <form class="d-flex p-1 ">
                    <input class="form-control me-1" style="width:30rem; border: 1px solid black;" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn" type="submit" style="background-color:#2541B2; Color: #fefeff;">Pesquisar</button>
                </form>
            </div>
        </div>

        <form class="row g-3 mt-1 mb-5" method="POST" action="">

            <div class="col-md-10 input">
                <label for="codigo" class="form-label">Nome do Trabalhador</label>
                <input type="text" class="form-control " name="codigo" value="" id="codigo">
            </div>

            <div class="col-md-2 input">
                <label for="matricula" class="form-label">Matrícula</label>
                <input type="text" class="form-control " name="matricula" value="" id="matricula">
            </div>

            <div class="col-md-2 input">
                <label for="codigo" class="form-label">Código</label>
                <input type="text" class="form-control " name="codigo" value="" id="codigo">
            </div>

            <div class="col-md-8 input">
                <label for="rubrica" class="form-label">Rúbrica</label>
                <input type="text" class="form-control " name="rubrica" value="" id="rubrica">
            </div>

            <div class="col-md-2 input">
                <label for="quantidade" class="form-label">Quantidade/Tonelada</label>
                <input type="text" class="form-control " name="quantidade" value="" id="quantidade">
            </div>
            

        </form>

        <table class="table table-sm border-bottom  text-white table-responsive mt-5" style="background-color: #353535;">
            <thead>
                <th class="col text-white">Cod</th>
                <th colspan="2" class="col text-white">Rúbrica</th>
                <th class="col text-white">Quantidade/Tonelada</th>
            </thead>
            <tbody>
                <td class="bg-light text-black">001</td>
                <td class="bg-light text-black">Diária Normal</td>
                <td class="bg-light text-black"></td>
                <td class="bg-light text-black">20</td>
            </tbody>
        </table>

        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header " style="background-image: linear-gradient(-120deg, rgb(32, 36, 236),rgb(16, 78, 248));">
                  <h5 class="modal-title text-white" id="staticBackdropLabel">Excluir</h5>
                  <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="background-color: #fffdfd;">
                  <p class="text-black text-start fs-5">Deseja realmente excluir?</p>
                </div>
                <div class="modal-footer" style="background-color: #fffdfd;">
                  <button type="button" class="btn text-white" data-bs-dismiss="modal" style="background-color:#1e53ff;">Fechar</button>
                  <form action="">
                  <a class="btn ms-2 text-white" href="#" role="button" style="background-color:#bb0202;">Deletar</a> 
                </form> 
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\mobe\blog\resources\views/criaTabela/index.blade.php ENDPATH**/ ?>