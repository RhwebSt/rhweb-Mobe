<?php $__env->startSection('conteine'); ?>
<div class="container">


                <?php if($errors->all()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($error === 'edittrue'): ?>
                <div class="alert alert-success mt-2 alert-block">
                    <strong>Atualização realizada com sucesso!</strong>
                </div>
             <?php elseif($error === 'editfalse'): ?>
                <div class="alert alert-danger mt-2 alert-block">
                    <strong>Não foi porssivél atualizar os dados!</strong>
                </div>
            <?php elseif($error === 'deletatrue'): ?>
                <div class="alert alert-success mt-2 alert-block">
                    <strong>Registro deletador com sucesso!</strong>
                </div>
             <?php elseif($error === 'cadastratrue'): ?>
                <div class="alert alert-success mt-2 alert-block">
                    <strong>Cadastrador realizada com sucesso!</strong>
                </div>
             <?php elseif($error === 'cadastrafalse'): ?>
                <div class="alert alert-danger mt-2 alert-block">
                    <strong>Não foi porssivél realizar o cadastro !</strong>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>     
              <form class="row g-3 mt-1 mb-3" id="form" method="POST" action="<?php echo e(route('tabelapreco.store')); ?>">
                <input type="hidden" value="<?php echo e($id); ?>" name="tomador">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="method" name="_method" value="">
                <div class="row">
                  <div class="btn mt-3 form-control" role="button" aria-label="Basic example">
                      
                      <button type="submit" class="btn btn-primary " id="incluir">
                      Incluir
                        </button>
                        <button type="submit" disabled class="btn btn-primary " id="atualizar">
                      Atualizar
                        </button>
                      <button type="button" disabled id="excluir" class="btn btn-primary ms-2  col-md-1" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                          Excluir
                        </button>
                        
                      
                      <a class="btn btn-primary ms-2 col-md-1" href="<?php echo e(route('tomador.index')); ?>" role="button">Sair</a>
                  </div>
              </div>
              <h5 class="card-title text-center fs-3 ">Tabela de Preços</h5>
                <div class="col-md-2">
                  <label for="ano" class="form-label">Ano</label>
                  <input type="text" class="form-control" name="ano" value="" id="ano">
                </div>

                <div class="col-md-2">
                    <label for="rubricas" class="form-label">Rúbricas</label>
                    <input type="text" class="form-control" name="rubricas" value="" id="rubricas">
                </div>

                <div class="col-md-7">
                  <label for="descricao" class="form-label">Descrição</label>
                  <input type="text" class="form-control" name="descricao"  id="descricao">
                </div>
                <input type="hidden" name="empresa" value="">
                <div class="col-md-1">
                  <label for="valor" class="form-label">Valor</label>
                  <input type="text" class="form-control" name="valor" value="" id="valor">
                </div>
              </form> 
              
              <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header " style="background-color:#000000;">
                      <h5 class="modal-title text-white" id="staticBackdropLabel">Excluir</h5>
                      <button type="button" class="btn-close bg-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <p class="text-black text-start">Deseja realmente excluir?</p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Fechar</button>
                      <form action="" id="formdelete" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                      <button type="submit" class="btn btn-danger">Deletar</button>
                    </form> 
                    </div>
                  </div>
                </div>
              </div>
            </div> 
            <script>
        $(document).ready(function(){
           
            $( "#descricao" ).keyup(function() {
                var dados = $(this).val();
                $.ajax({
                    url: "<?php echo e(url('tabelapreco')); ?>/"+dados,
                    type: 'get',
                    contentType: 'application/json',
                    success: function(data) {
                      console.log(data)
                        if (data.id) {
                            $('#form').attr('action', "<?php echo e(url('tabelapreco')); ?>/"+data.id);
                            $('#formdelete').attr('action',"<?php echo e(url('tabelapreco')); ?>/"+data.id)
                            $('#incluir').attr('disabled','disabled')
                            $('#atualizar').removeAttr( "disabled" )
                            $('#deletar').removeAttr( "disabled" )
                            $('#excluir').removeAttr( "disabled" )
                            $('#method').val('PUT')
                            $('#ano').val(data.tsano)
                            $('#rubricas').val(data.tsrubrica)
                            $('#valor').val(data.tsvalor.toString().replace(".", ","))
                        }else{
                            $('#form').attr('action', "<?php echo e(route('tabelapreco.store')); ?>");
                            $('#incluir').removeAttr( "disabled" )
                            $('#atualizar').attr('disabled','disabled')
                            $('#deletar').attr('disabled','disabled')
                            $('#method').val(' ')
                            $('#excluir').attr( "disabled","disabled" )
                        }
                      
                    }
                });
            });
        });
    </script>   
            <?php $__env->stopSection(); ?>    
           
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\mobe\blog\resources\views/tomador/tabelapreco/index.blade.php ENDPATH**/ ?>