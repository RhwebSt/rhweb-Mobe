<?php $__env->startSection('conteine'); ?>

<div class="container d-flex justify-content-center flex-column align-items-center" style="margin-top: 300px">
              <img class="img-fluid" src="<?php echo e(url('/imagem/rhwebll.png')); ?>" alt="" srcset="" style="">
            </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\mobe\blog\resources\views/login/home.blade.php ENDPATH**/ ?>