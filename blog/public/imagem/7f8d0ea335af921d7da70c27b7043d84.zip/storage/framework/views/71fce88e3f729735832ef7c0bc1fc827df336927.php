
<?php $__env->startSection('conteine'); ?>
<div class="card-body">
      <?php if($errors->all()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($error === 'edittrue'): ?>
                <div class="alert alert-success mt-2 alert-block">
                    <strong>Atualização realizada com sucesso!</strong>
                </div>
             <?php elseif($error === 'editfalse'): ?>
                <div class="alert alert-danger mt-2 alert-block">
                    <strong>Não foi porssivél atualizar os dados!</strong>
                </div>
            <?php elseif($error === 'deletatrue'): ?>
                <div class="alert alert-success mt-2 alert-block">
                    <strong>Registro deletador com sucesso!</strong>
                </div>
             <?php elseif($error === 'cadastratrue'): ?>
                <div class="alert alert-success mt-2 alert-block">
                    <strong>Cadastrador realizada com sucesso!</strong>
                </div>
             <?php elseif($error === 'cadastrafalse'): ?>
                <div class="alert alert-danger mt-2 alert-block">
                    <strong>Não foi porssivél realizar o cadastro !</strong>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>     
              <h5 class="card-title text-center fs-3 ">Lançamento com Tabela</h5>
              <form class="row g-3 mt-1 mb-3" id="form" method="POST" action="<?php echo e(route('cadastrocartaoponto.store')); ?>">
              <?php echo csrf_field(); ?>
              <input type="hidden" id="method" name="_method" value="">
                <div class="row">
                  <div class="btn mt-3 form-control" role="button" aria-label="Basic example">
       
                        <button type="submit" id="incluir" class="btn btn-primary">Incluir</button>
                        <button type="submit" id="atualizar" disabled class="btn btn-primary">Editar</button>
                        <button type="button" class="btn btn-primary  " disabled id="excluir" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                          Excluir
                      </button>
                      
               
                    <a class="btn btn btn-primary" href="<?php echo e(route('home.index')); ?>" role="button">Sair</a>
                  </div>
              </div>

                <div class="col-md-6 input">
                  <label for="tomador" class="form-label">Tomador</label>
                  <input type="text" class="form-control " name="nome__completo" value="" id="nome__completo">
                </div>
                  <input type="hidden" name="tomador" id="tomador">
                  <input type="hidden" id="domingo" name="domingo">
                  <input type="hidden" name="sabado" id="sabado">
                  <input type="hidden" name="diasuteis" id="diasuteis">
                <div class="col-md-1">
                    <label for="matricula" class="form-label">Matrícula</label>
                    <input type="text" class="form-control " name="matricula" value="" id="matricula">
                  </div>

                <div class="col-md-2">
                    <label for="num__boletim" class="form-label">Nº do Boletim</label>
                    <input type="text" class="form-control" name="num__boletim" id="num__boletim">
                </div>

                <div class="col-md-2">
                  <label for="data" class="form-label">Data</label>
                  <input type="date" class="form-control" name="data" value="" id="data">
                </div>

                <div class="col-md-2">
                  <label for="num__trabalhador" class="form-label">Nº de Trabalhador</label>
                  <input type="text" class="form-control" name="num__trabalhador" value="" id="num__trabalhador">
                </div>
              </form> 
              
              <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header " style="background-image: linear-gradient(-120deg, rgb(32, 36, 236),rgb(16, 78, 248));">
                      <h5 class="modal-title text-white" id="staticBackdropLabel">Excluir</h5>
                      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" style="background-color: #fffdfd;">
                      <p class="text-black text-start fs-5">Deseja realmente excluir?</p>
                    </div>
                    <div class="modal-footer" style="background-color: #fffdfd;">
                      <button type="button" class="btn text-white" data-bs-dismiss="modal" style="background-color:#1e53ff;">Fechar</button>
                    <form action="" id="formdelete" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                      
                      <button type="submit" class="btn btn-danger">Deletar</button>
                    </form> 
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <script>
               $( "#num__boletim" ).keyup(function() {
                var dados = $(this).val();
                if (dados) {
                    $.ajax({
                        url: "<?php echo e(url('tabcartaoponto')); ?>/"+dados,
                        type: 'get',
                        contentType: 'application/json',
                        success: function(data) {
                          if (data.id) {
                                $('#form').attr('action', "<?php echo e(url('cadastrocartaoponto')); ?>/"+data.id);
                                $('#formdelete').attr('action',"<?php echo e(url('cadastrocartaoponto')); ?>/"+data.id)
                                $('#incluir').attr('disabled','disabled')
                                $('#atualizar').removeAttr( "disabled" )
                                $('#deletar').removeAttr( "disabled" )
                                $('#excluir').removeAttr( "disabled" )
                                $('#method').val('PUT')
                            
                            }else{
                                $('#form').attr('action', "<?php echo e(route('cadastrocartaoponto.store')); ?>");
                                $('#incluir').removeAttr( "disabled" )
                                $('#atualizar').attr('disabled','disabled')
                                $('#deletar').attr('disabled','disabled')
                                $('#method').val(' ')
                                $('#excluir').attr( "disabled",'disabled' )
                            }
                            $('#data').val(data.lsdata)
                            $('#num__trabalhador').val(data.lsnumero)
                        }
                    });
                }
            });
               $( "#nome__completo" ).keyup(function() {
                var dados = $( "#nome__completo" ).val();
                if (dados) {
                    $.ajax({
                        url: "<?php echo e(url('tomador')); ?>/"+dados,
                        type: 'get',
                        contentType: 'application/json',
                        success: function(data) {
                          if (data.id) {
                            $('#tomador').val(data.tomador)
                            $('#matricula').val(data.tsmatricula)
                            $('#domingo').val(data.csdomingos)
                            $('#sabado').val(data.cssabados)
                            $('#diasuteis').val(data.csdiasuteis)
                          }
                          
                        }
                    });
                }
            });
            </script>         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/mobema08/rh.mobemaodeobra.com.br/resources/views/cadastroCartaoPonto/index.blade.php ENDPATH**/ ?>