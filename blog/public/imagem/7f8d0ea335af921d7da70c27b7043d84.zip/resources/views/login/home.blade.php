@extends('layouts.index')
@section('conteine')

<div class="container d-flex justify-content-center flex-column align-items-center" style="margin-top: 300px">
              <img class="img-fluid" src="{{url('/imagem/rhwebll.png')}}" alt="" srcset="" style="">
            </div>
        
@stop